
const servicesData = [
    {
      link: '/services',
      imgSrc: '/servicesAsset/servcire-1.png',
      title: 'Divorce Issue',
    },
    {
      link: '/services',
      imgSrc: '/servicesAsset/servies-2.jpeg',
      title: 'Family Issues',
    },
    {
      link: '/services',
      imgSrc: '/servicesAsset/servies3.jpeg',
      title: 'Love Marriage',
    },
    {
      link: '/services',
      imgSrc: '/servicesAsset/servies4.jpeg',
      title: 'Success in Exams',
    },
    {
      link: '/services',
      imgSrc: '/servicesAsset/servies5.jpeg',
      title: 'Breakup',
    },
    {
      link: '/services',
      imgSrc: '/servicesAsset/servies6.jpeg',
      title: 'Children Marriage Issues',
    },
  ];
  export default servicesData