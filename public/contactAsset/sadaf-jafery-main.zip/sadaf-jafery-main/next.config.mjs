/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['www.sadafjaffery.com'],
      },
};

export default nextConfig;
